// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;
import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        GameController gc = GameController.getInstance();

        UserInputObserver ui = new UserInputObserver();

        ui.addObserver(gc);
}
}