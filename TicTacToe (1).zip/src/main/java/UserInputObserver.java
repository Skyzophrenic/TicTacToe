
public class UserInputObserver implements Subject {
  protected InputCommand currentInputCommand;

  public void createInput(boolean isPlayer, int targetLocation) {
    InputCommand command = new InputCommand(isPlayer, targetLocation);
    currentInputCommand = command;
    notifyObservers(); 
  }

  public void sendInput() {
  }

  public void addObserver(Observer o) {
    obs.add(o);

  }

  public void removeObserver(Observer o) {
    obs.remove(o);

  }

  public void notifyObservers() {
    for (Observer observer : obs) {
        observer.update(currentInputCommand);
    }

  }

}