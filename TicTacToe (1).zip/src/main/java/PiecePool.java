import java.util.ArrayList;

public class PiecePool {
    private ArrayList<GamePiece> pool;

    public PiecePool() {
        pool = new ArrayList<GamePiece>();
        this.spawnPool(9);
    }

    public void spawnPool(int i) {
        for (int j = 0; j < i; j++) {
            System.out.println("Creating Piece # " + j);
            pool.add(new GamePiece());
        }
    }

    // Method to add a GamePiece to the pool
    public void addPiece(GamePiece piece) {
        pool.add(piece);
    }

    // Method to get a GamePiece from the pool by index
    public GamePiece getPiece(int index) {
        if (index >= 0 && index < pool.size()) {
            return pool.get(index);
        }
        return null; // Or throw an exception
    }

    public GamePiece getPiece(boolean isPlayer, int index) {
        if (index >= 0 && index < pool.size()) {
            pool.get(index).isPlayer = isPlayer;
            return pool.get(index);
        }
        return null; // Or throw an exception
    }

    // Method to get the size of the pool
    public int size() {
        return pool.size();
    }

    // Additional methods can be added as needed
}
