
public class InputCommand {
  protected boolean isPlayer;
  protected int targetLocation;

  public InputCommand(boolean isPlayer, int targetLocation) {
    this.isPlayer = isPlayer;
    this.targetLocation = targetLocation;
  }
}