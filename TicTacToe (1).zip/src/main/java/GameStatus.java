public enum GameStatus {
    WIN, LOSE, DRAW, CONTINUE
}