public interface Observer{
  void update(InputCommand command);
}