import java.awt.*;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Board extends JFrame {
    protected GamePiece[] boardSlots = new GamePiece[9];
    JButton[] buttons = new JButton[9];
    public UserInputObserver ui;
    private JLabel statusLabel;
    private JPanel mainPanel;
    private JPanel gamePanel;

    private static final Color BACKGROUND_COLOR = new Color(30, 33, 40);
    private static final Color HOVER_COLOR = new Color(45, 48, 55);
    private static final Color X_COLOR = new Color(235, 87, 87);
    private static final Color O_COLOR = new Color(86, 182, 255);
    private static final Color GRID_COLOR = new Color(50, 53, 60);
    private static final Color TEXT_COLOR = new Color(200, 200, 200);

    private class ButtonClickListener implements ActionListener {
        private int index;

        public ButtonClickListener(int index) {
            this.index = index;
        }

        public void actionPerformed(ActionEvent e) {
            if (buttons[index].getText().equals(" ")) {
                ui.createInput(GameController.getInstance().isPlayerTurn, index);
                String turn = GameController.getInstance().passTurn();
                buttons[index].setText(turn);
                buttons[index].setForeground(turn.equals("X") ? X_COLOR : O_COLOR);
                updateStatusLabel(turn.equals("O") ? "X's turn" : "O's turn");
            }
        }
    }

    public Board() {
        this.setTitle("Tic Tac Toe");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(BACKGROUND_COLOR);
        this.ui = new UserInputObserver();

        mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(BACKGROUND_COLOR);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("Tic Tac Toe", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
        titleLabel.setForeground(TEXT_COLOR);
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        statusLabel = new JLabel("X's turn", SwingConstants.CENTER);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        statusLabel.setForeground(TEXT_COLOR);
        mainPanel.add(statusLabel, BorderLayout.SOUTH);

        gamePanel = new JPanel(new GridLayout(3, 3, 8, 8));
        gamePanel.setBackground(GRID_COLOR);
        gamePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        Font gameFont = new Font("Segoe UI", Font.BOLD, 120);

        for (int i = 0; i < buttons.length; i++) {
            buttons[i] = new JButton(" ") {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(getBackground());
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                    super.paintComponent(g);
                }


                @Override
                public Dimension getPreferredSize() {
                    return new Dimension(160, 160);
                }
            };

            buttons[i].setFont(gameFont);
            buttons[i].setFocusPainted(false);
            buttons[i].setBackground(BACKGROUND_COLOR);
            buttons[i].setForeground(X_COLOR);
            buttons[i].setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); 
            buttons[i].setContentAreaFilled(false);
            buttons[i].setOpaque(true);

            buttons[i].setVerticalAlignment(SwingConstants.CENTER);
            buttons[i].setHorizontalAlignment(SwingConstants.CENTER);

            final int index = i;
            buttons[i].addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    if (buttons[index].getText().trim().equals(" ")) {
                        buttons[index].setBackground(HOVER_COLOR);
                    }
                }
                public void mouseExited(MouseEvent e) {
                    buttons[index].setBackground(BACKGROUND_COLOR);
                }
            });

            buttons[i].addActionListener(new ButtonClickListener(i));
            gamePanel.add(buttons[i]);
        }

        mainPanel.add(gamePanel, BorderLayout.CENTER);
        this.add(mainPanel);
        this.pack();
        this.setSize(650, 750);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setVisible(true);
    }

    private void updateStatusLabel(String status) {
        statusLabel.setText(status);
    }

    public void placePiece(GamePiece piece, int position) {
        boardSlots[position] = piece;
        if (piece != null) {
            buttons[position].setText(piece.toString());
            buttons[position].setForeground(piece.toString().equals("X") ? X_COLOR : O_COLOR);
        }
    }

    public GamePiece getPosition(int position) {
        return boardSlots[position];
    }
}